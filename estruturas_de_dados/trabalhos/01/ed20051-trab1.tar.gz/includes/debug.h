#define INVARIANTE(expr, msg)	if(! (expr) ) throw new TEInvariant(msg);
